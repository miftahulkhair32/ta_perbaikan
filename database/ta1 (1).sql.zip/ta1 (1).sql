-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 19 Mei 2018 pada 20.48
-- Versi Server: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ta1`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `bulan` varchar(45) NOT NULL,
  `artikel` varchar(250) DEFAULT NULL,
  `judul` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id`, `user`, `bulan`, `artikel`, `judul`) VALUES
(1, 2, 'Mei', '', 'test'),
(2, 3, 'Mei', '', 'wew');

-- --------------------------------------------------------

--
-- Struktur dari tabel `observasi`
--

CREATE TABLE `observasi` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `bulan` varchar(45) NOT NULL,
  `miftahul` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `observasi`
--

INSERT INTO `observasi` (`id`, `user`, `bulan`, `miftahul`) VALUES
(1, 2, 'Mei', 90),
(2, 3, 'Mei', 77);

-- --------------------------------------------------------

--
-- Struktur dari tabel `partisipasi`
--

CREATE TABLE `partisipasi` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `bulan` varchar(45) NOT NULL,
  `total` int(11) DEFAULT NULL,
  `keterangan` mediumtext,
  `hadir1` int(11) DEFAULT NULL,
  `lambat1` int(11) DEFAULT NULL,
  `tidak1` int(11) DEFAULT NULL,
  `kurang1` int(11) DEFAULT NULL,
  `hadir2` int(11) DEFAULT NULL,
  `lambat2` int(11) DEFAULT NULL,
  `tidak2` int(11) DEFAULT NULL,
  `kurang2` int(11) DEFAULT NULL,
  `hadir3` int(11) DEFAULT NULL,
  `lambat3` int(11) DEFAULT NULL,
  `tidak3` int(11) DEFAULT NULL,
  `kurang3` int(11) DEFAULT NULL,
  `hadir4` int(11) DEFAULT NULL,
  `lambat4` int(11) DEFAULT NULL,
  `tidak4` int(11) DEFAULT NULL,
  `kurang4` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `partisipasi`
--

INSERT INTO `partisipasi` (`id`, `user`, `bulan`, `total`, `keterangan`, `hadir1`, `lambat1`, `tidak1`, `kurang1`, `hadir2`, `lambat2`, `tidak2`, `kurang2`, `hadir3`, `lambat3`, `tidak3`, `kurang3`, `hadir4`, `lambat4`, `tidak4`, `kurang4`) VALUES
(1, 2, 'Mei', 377, '', 86, 0, 0, -24, 90, 0, 0, -20, 100, 0, 0, -10, 101, 0, 0, -9),
(2, 3, 'Mei', 403, '', 106, 0, 0, -4, 100, 0, 0, -10, 99, 0, 0, -11, 98, 0, 0, -12);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggaran`
--

CREATE TABLE `pelanggaran` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `bulan` varchar(45) NOT NULL,
  `total` int(11) DEFAULT NULL,
  `pelanggaran` longtext,
  `keterangan` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pelanggaran`
--

INSERT INTO `pelanggaran` (`id`, `user`, `bulan`, `total`, `pelanggaran`, `keterangan`) VALUES
(1, 2, 'Mei', 340, 'Tidak berniat ikhlas karena Allah   Tidak sholat fardhu dengan sengaja                                                  ', 'blo'),
(2, 3, 'Mei', 4, '       Tidak mengikuti kegiatan tilawah qur’an, dzikir dan shalat sunnah rawatib                                              ', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pencapaian`
--

CREATE TABLE `pencapaian` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `bulan` varchar(45) NOT NULL,
  `total` int(11) DEFAULT NULL,
  `na1` int(11) DEFAULT NULL,
  `na2` int(11) DEFAULT NULL,
  `na3` int(11) DEFAULT NULL,
  `na4` int(11) DEFAULT NULL,
  `b1` varchar(200) DEFAULT NULL,
  `nb1` int(11) DEFAULT NULL,
  `c1` varchar(200) DEFAULT NULL,
  `nc1` int(11) DEFAULT NULL,
  `d1a` varchar(200) DEFAULT NULL,
  `nd1a` int(11) DEFAULT NULL,
  `d2a` varchar(200) DEFAULT NULL,
  `nd2a` int(11) DEFAULT NULL,
  `d2b` varchar(200) DEFAULT NULL,
  `nd2b` int(11) DEFAULT NULL,
  `d2c` varchar(200) DEFAULT NULL,
  `nd2c` int(11) DEFAULT NULL,
  `d2d` varchar(200) DEFAULT NULL,
  `nd2d` int(11) DEFAULT NULL,
  `d3a` varchar(200) DEFAULT NULL,
  `nd3a` int(11) DEFAULT NULL,
  `d3b` varchar(200) DEFAULT NULL,
  `nd3b` int(11) DEFAULT NULL,
  `d3c` varchar(200) DEFAULT NULL,
  `nd3c` int(11) DEFAULT NULL,
  `d3d` varchar(200) DEFAULT NULL,
  `nd3d` int(11) DEFAULT NULL,
  `d3e` varchar(200) DEFAULT NULL,
  `nd3e` int(11) DEFAULT NULL,
  `d3f` varchar(200) DEFAULT NULL,
  `nd3f` int(11) DEFAULT NULL,
  `d4a` varchar(200) DEFAULT NULL,
  `nd4a` int(11) DEFAULT NULL,
  `d4b` varchar(200) DEFAULT NULL,
  `nd4b` int(11) DEFAULT NULL,
  `d5a` varchar(200) DEFAULT NULL,
  `nd5a` int(11) DEFAULT NULL,
  `d5b` varchar(200) DEFAULT NULL,
  `nd5b` int(11) DEFAULT NULL,
  `d5c` varchar(200) DEFAULT NULL,
  `nd5c` int(11) DEFAULT NULL,
  `d5d` varchar(200) DEFAULT NULL,
  `nd5d` int(11) DEFAULT NULL,
  `d5e` varchar(200) DEFAULT NULL,
  `nd5e` int(11) DEFAULT NULL,
  `d5f` varchar(200) DEFAULT NULL,
  `nd5f` int(11) DEFAULT NULL,
  `d6a` varchar(200) DEFAULT NULL,
  `nd6a` int(11) DEFAULT NULL,
  `d7a` varchar(200) DEFAULT NULL,
  `nd7a` int(11) DEFAULT NULL,
  `d8a` varchar(200) DEFAULT NULL,
  `nd8a` int(11) DEFAULT NULL,
  `d8b` varchar(200) DEFAULT NULL,
  `nd8b` int(11) DEFAULT NULL,
  `d9a` varchar(200) DEFAULT NULL,
  `nd9a` int(11) DEFAULT NULL,
  `d10a` varchar(200) DEFAULT NULL,
  `nd10a` int(11) DEFAULT NULL,
  `d10b` varchar(200) DEFAULT NULL,
  `nd10b` int(11) DEFAULT NULL,
  `e1` varchar(200) DEFAULT NULL,
  `ne1` int(11) DEFAULT NULL,
  `f1` varchar(200) DEFAULT NULL,
  `nf1` int(11) DEFAULT NULL,
  `f2` varchar(200) DEFAULT NULL,
  `nf2` int(11) DEFAULT NULL,
  `f3` varchar(200) DEFAULT NULL,
  `nf3` int(11) DEFAULT NULL,
  `f4` varchar(200) DEFAULT NULL,
  `nf4` int(11) DEFAULT NULL,
  `f5` varchar(200) DEFAULT NULL,
  `nf5` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pencapaian`
--

INSERT INTO `pencapaian` (`id`, `user`, `bulan`, `total`, `na1`, `na2`, `na3`, `na4`, `b1`, `nb1`, `c1`, `nc1`, `d1a`, `nd1a`, `d2a`, `nd2a`, `d2b`, `nd2b`, `d2c`, `nd2c`, `d2d`, `nd2d`, `d3a`, `nd3a`, `d3b`, `nd3b`, `d3c`, `nd3c`, `d3d`, `nd3d`, `d3e`, `nd3e`, `d3f`, `nd3f`, `d4a`, `nd4a`, `d4b`, `nd4b`, `d5a`, `nd5a`, `d5b`, `nd5b`, `d5c`, `nd5c`, `d5d`, `nd5d`, `d5e`, `nd5e`, `d5f`, `nd5f`, `d6a`, `nd6a`, `d7a`, `nd7a`, `d8a`, `nd8a`, `d8b`, `nd8b`, `d9a`, `nd9a`, `d10a`, `nd10a`, `d10b`, `nd10b`, `e1`, `ne1`, `f1`, `nf1`, `f2`, `nf2`, `f3`, `nf3`, `f4`, `nf4`, `f5`, `nf5`) VALUES
(1, 2, 'Mei', 398, 89, 25, 24, 45, 'menguasai tahsin dan 7 huruf', 46, 'menghapal 30 juz dalam 1 milisecond', 100, '', 34, '', 35, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0),
(2, 3, 'Mei', 480, 80, 90, 100, 100, 'menguasai mad sepenuhnya', 100, 'hapal qur\'an selama 1000 tahun', 10, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tahfizh`
--

CREATE TABLE `tahfizh` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `bulan` varchar(45) NOT NULL,
  `halaman` varchar(45) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `tgl1` date DEFAULT NULL,
  `salah1` int(11) DEFAULT NULL,
  `tajw1` int(11) DEFAULT NULL,
  `makna1` int(11) DEFAULT NULL,
  `tgl2` date DEFAULT NULL,
  `salah2` int(11) DEFAULT NULL,
  `tajw2` int(11) DEFAULT NULL,
  `makna2` int(11) DEFAULT NULL,
  `tgl3` date DEFAULT NULL,
  `salah3` int(11) DEFAULT NULL,
  `tajw3` int(11) DEFAULT NULL,
  `makna3` int(11) DEFAULT NULL,
  `tgl4` date DEFAULT NULL,
  `salah4` int(11) DEFAULT NULL,
  `tajw4` int(11) DEFAULT NULL,
  `makna4` int(11) DEFAULT NULL,
  `tgl5` date DEFAULT NULL,
  `salah5` int(11) DEFAULT NULL,
  `tajw5` int(11) DEFAULT NULL,
  `makna5` int(11) DEFAULT NULL,
  `tgl6` date DEFAULT NULL,
  `salah6` int(11) DEFAULT NULL,
  `tajw6` int(11) DEFAULT NULL,
  `makna6` int(11) DEFAULT NULL,
  `tgl7` date DEFAULT NULL,
  `salah7` int(11) DEFAULT NULL,
  `tajw7` int(11) DEFAULT NULL,
  `makna7` int(11) DEFAULT NULL,
  `tgl8` date DEFAULT NULL,
  `salah8` int(11) DEFAULT NULL,
  `tajw8` int(11) DEFAULT NULL,
  `makna8` int(11) DEFAULT NULL,
  `tgl9` date DEFAULT NULL,
  `salah9` int(11) DEFAULT NULL,
  `tajw9` int(11) DEFAULT NULL,
  `makna9` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tahfizh`
--

INSERT INTO `tahfizh` (`id`, `user`, `bulan`, `halaman`, `total`, `tgl1`, `salah1`, `tajw1`, `makna1`, `tgl2`, `salah2`, `tajw2`, `makna2`, `tgl3`, `salah3`, `tajw3`, `makna3`, `tgl4`, `salah4`, `tajw4`, `makna4`, `tgl5`, `salah5`, `tajw5`, `makna5`, `tgl6`, `salah6`, `tajw6`, `makna6`, `tgl7`, `salah7`, `tajw7`, `makna7`, `tgl8`, `salah8`, `tajw8`, `makna8`, `tgl9`, `salah9`, `tajw9`, `makna9`) VALUES
(1, 2, 'Mei', '3000', 136, '2018-05-01', 12, 32, 12, '2018-05-25', 23, 12, 45, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0),
(2, 3, 'Mei', '', 592, '2018-05-02', 45, 64, 64, '2018-05-08', 76, 23, 75, '2018-05-17', 85, 85, 75, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0, '0000-00-00', 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nim` int(11) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(50) NOT NULL,
  `daerah` varchar(80) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('santri','menejemen') NOT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nim`, `nama`, `username`, `email`, `daerah`, `password`, `status`, `foto`) VALUES
(1, NULL, 'miftahul khair', 'miftahul', 'miftahul.khair.k.r@gmail.com', 'ponti', '$2y$10$pfbYkyBtYiYa0j27zDlCaupna3aX5eHxIOIwUJBjsbNEgZMpdAF7m', 'menejemen', 'mifta.jpg'),
(2, 123456741, 'zakky mantap', 'zakky', 'zak.k@petik.or.id', 'cilodong', '$2y$05$FZdQZ2DshkX33.GnIy/zPOFfiHRNf7fvDsW7QWwyf4KIvqwZyCC4i', 'santri', '4192.jpg'),
(3, 1236454, 'ikwan gea', 'gea', 'gea@jiah.com', 'nias', '$2y$05$ePSLCUIDaNb1E2hLmLPvfOX/Ss.WTQZPE5e4aajvNixg9S0sYBaFK', 'santri', 'Cuplikan_layar_dari_2018-04-29_14-59-16.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_artikel_user_idx` (`user`);

--
-- Indexes for table `observasi`
--
ALTER TABLE `observasi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_observasi_user1_idx` (`user`);

--
-- Indexes for table `partisipasi`
--
ALTER TABLE `partisipasi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_partisipasi_user1_idx` (`user`);

--
-- Indexes for table `pelanggaran`
--
ALTER TABLE `pelanggaran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_pelanggaran_user1_idx` (`user`);

--
-- Indexes for table `pencapaian`
--
ALTER TABLE `pencapaian`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_pencapaian_user1_idx` (`user`);

--
-- Indexes for table `tahfizh`
--
ALTER TABLE `tahfizh`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `fk_tahfizh_user1_idx` (`user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `nim_UNIQUE` (`nim`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `observasi`
--
ALTER TABLE `observasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `partisipasi`
--
ALTER TABLE `partisipasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pelanggaran`
--
ALTER TABLE `pelanggaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pencapaian`
--
ALTER TABLE `pencapaian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tahfizh`
--
ALTER TABLE `tahfizh`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD CONSTRAINT `fk_artikel_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `observasi`
--
ALTER TABLE `observasi`
  ADD CONSTRAINT `fk_observasi_user1` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `partisipasi`
--
ALTER TABLE `partisipasi`
  ADD CONSTRAINT `fk_partisipasi_user1` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `pelanggaran`
--
ALTER TABLE `pelanggaran`
  ADD CONSTRAINT `fk_pelanggaran_user1` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `pencapaian`
--
ALTER TABLE `pencapaian`
  ADD CONSTRAINT `fk_pencapaian_user1` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `tahfizh`
--
ALTER TABLE `tahfizh`
  ADD CONSTRAINT `fk_tahfizh_user1` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
